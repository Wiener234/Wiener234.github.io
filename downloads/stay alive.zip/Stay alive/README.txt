Zum spielen unter Windows geht man mit den Pfeiltasten direkt nach Spiel start auf Keyboard und nutzt nicht die Maus.
Die .apk ist für Android Handys
