------------------------------------------------------------
------------------------------------------------------------

Create a Github account and install Git.

------------------------------------------------------------
------------------------------------------------------------

Then create a token for your Github account.
There for go to https://github.com.
Then go to:
	-settings
	-Developer settings
	-Personal access tokens
Now follow the steps to create that token.

------------------------------------------------------------
------------------------------------------------------------

After the token is created open the .env file and give your
FILEPATH, TOKEN and USERNAME.

------------------------------------------------------------
------------------------------------------------------------

Now import the requierd modules by typing in the
following command:

cd "your path"				# replace "your path" withe your path 		example(C:\users\nilsb\desktop)
pip install -r requirements.txt

------------------------------------------------------------
------------------------------------------------------------

The last step is to add the folder "git automation" to your
path by going into your control panal then to system  and 
advanced system settings.
Under expanded goto enviormaental varables. Ther you goto
path and add it there.

------------------------------------------------------------

Now you can open CMD and type in create "repo name" to 
create a repo and add "repo name" "comitte name" to add 
files to your repo and commit them.

